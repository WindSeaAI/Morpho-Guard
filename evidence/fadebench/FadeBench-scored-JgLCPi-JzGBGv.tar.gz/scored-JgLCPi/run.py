import hashlib
import json
import os
import subprocess
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, LogitsProcessorList

out = Path(__file__).resolve().parent
work = out.parent
repo = work / "fadebench"
guard_repo = work / "morpho-guard"
os.chdir(repo)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify_repo(path, expected):
    head = subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()
    if head != expected:
        raise RuntimeError(f"Unexpected commit: {path} {head}")
    subprocess.run(["git", "-C", str(path), "diff", "--quiet", "HEAD", "--"], check=True)

verify_repo(repo, "c1c0bdf3f8758fdc990fcf4ef22a78da4e4f28b0")
verify_repo(guard_repo, "313fec91fb6061467e0cd6a44c9ff7f585362a19")
inventory = (work / "fadebench_gradient_inventory.json").read_bytes()
if sha(inventory) != "c953f2b523d8ef14fbbbf2729362f7db8d8db7568680fa1e90c2be295bb28773":
    raise RuntimeError("Inventory hash mismatch")
(out / "inventory.json").write_bytes(inventory)

sys.path.insert(0, str(repo / "fadebench/runner"))
sys.path.insert(0, str(guard_repo / "public"))
import run_gradient as runner
from generation_guard import GenerationGuard

items_dir = out / "items"
items_dir.mkdir()
plan = []
for entry in json.loads(inventory)["items"]:
    src = repo / entry["path"]
    data = src.read_bytes()
    if sha(data) != entry["source_sha256"]:
        raise RuntimeError(f"Source changed: {src}")
    if src.stem == "rc-01":
        continue
    lines = data.splitlines(keepends=True)
    if not lines[-1].startswith(b"<!-- FadeBench canary GUID "):
        raise RuntimeError(f"Unexpected final line: {src}")
    dest = items_dir / src.name
    dest.write_bytes(b"".join(lines[:-1]))
    flags = []
    if src.stem in {"gd-23b", "gd-23n"}:
        flags = ["--era3"]
    elif src.stem.startswith(("rc-01-", "gd-05-cold-")) or src.stem == "gd-24g":
        flags = ["--acute-only"]
    plan.append({"item": src.name, "flags": flags, "input_sha256": sha(dest.read_bytes())})

assert len(plan) == 80
(out / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
model_id = "Qwen2.5-1.5B-Instruct"
model_path = Path("/root/autodl-tmp/models") / model_id
tok = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(
    model_path, local_files_only=True, dtype=torch.float16
).to("cuda").eval()

# The official runner supplies the sample index. Keep it with each HTTP event.
original_sample = runner.run_sample
context = {}
def logged_sample(endpoint, system, setup, item, arm, config, sample, *args, **kwargs):
    context.update(sample=sample, request_index=0)
    return original_sample(endpoint, system, setup, item, arm, config, sample, *args, **kwargs)
runner.run_sample = logged_sample

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send_json(self, status, obj):
        data = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/v1/models":
            self.send_json(200, {"data": [{"id": model_id}]})
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path != "/v1/completions":
            self.send_error(404)
            return
        context["request_index"] += 1
        event = dict(context)
        try:
            req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            event["request"] = req
            if (req["temperature"], req["top_p"], req["max_tokens"]) != (0.7, 0.95, 256):
                raise ValueError("Unexpected sampling settings")
            inputs = tok(req["prompt"], add_special_tokens=False, return_tensors="pt").to("cuda")
            n = inputs.input_ids.shape[1]
            stops = [tok.encode(s, add_special_tokens=False) for s in req["stop"]]
            if any(len(ids) != 1 for ids in stops):
                raise ValueError("Unexpected ChatML stop sequence")
            eos = sorted({tok.eos_token_id, *(ids[0] for ids in stops)})
            guard = None
            processors = LogitsProcessorList()
            if context["condition"] == "morpho":
                guard = GenerationGuard(tok, n, tok.eos_token_id)
                processors.append(guard)
            torch.manual_seed(req["seed"])
            with torch.inference_mode():
                seq = model.generate(
                    **inputs, do_sample=True, num_beams=1, temperature=req["temperature"],
                    top_p=req["top_p"], top_k=0, max_new_tokens=req["max_tokens"],
                    logits_processor=processors, eos_token_id=eos, pad_token_id=tok.eos_token_id,
                )
            ids = seq[0, n:].tolist()
            stopped = bool(ids and ids[-1] in eos)
            reply = tok.decode(ids[:-1] if stopped else ids, skip_special_tokens=False)
            finish = "stop" if stopped else "length"
            step = guard.trigger_step if guard is not None else None
            event.update(reply=reply, generated_ids=ids, trigger_step=step,
                         finish_reason=finish, prompt_tokens=n)
            with (out / "requests.jsonl").open("a", encoding="utf-8") as f:
                print(json.dumps(event, ensure_ascii=False), file=f)
            self.send_json(200, {"choices": [{"text": reply, "finish_reason": finish}]})
        except Exception as exc:
            traceback.print_exc()
            event["error"] = repr(exc)
            with (out / "errors.jsonl").open("a", encoding="utf-8") as f:
                print(json.dumps(event, ensure_ascii=False), file=f)
            self.send_json(500, {"error": str(exc)})

with HTTPServer(("127.0.0.1", 0), Handler) as server:
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    endpoint = f"http://127.0.0.1:{server.server_port}"
    try:
        completed = 0
        for item in plan:
            for condition in ("base", "morpho"):
                name = item["item"]
                cell = out / condition / Path(name).stem
                cell.mkdir(parents=True)
                context.update(condition=condition, item=name)
                print(f"START {completed + 1}/160 {condition} {name}", flush=True)
                sys.argv = [
                    "run_gradient.py", "--item", str(items_dir / name),
                    "--out", str(cell), "--endpoint", endpoint, "--arm", "control",
                    "--config", "vanilla", "--chat-format", "chatml",
                    "--model-id", model_id, "--k", "5", "--seed", "20260822",
                    *item["flags"],
                ]
                if runner.main() != 0:
                    raise RuntimeError(f"Runner failed: {cell}")
                log, = cell.glob("*.jsonl")
                samples = [json.loads(line) for line in log.read_text().splitlines()]
                if sorted(r["sample"] for r in samples) != list(range(5)):
                    raise RuntimeError(f"Missing or duplicate samples: {cell}")
                if any(r.get("errors") for r in samples):
                    raise RuntimeError(f"Generation error recorded: {cell}")
                completed += 1
                print(f"DONE {completed}/160 {condition} {name}", flush=True)
        print("COLLECTION COMPLETE: 160 cells, 800 sample records. Scoring pending.", flush=True)
    finally:
        server.shutdown()
        thread.join()
